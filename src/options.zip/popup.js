// Use browser-specific API namespace
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

document.addEventListener('DOMContentLoaded', () => {
    const disposableEmailInput = document.getElementById('disposableEmail');
    const copyEmailButton = document.getElementById('copyEmail');
    const generateEmailButton = document.getElementById('generateEmail');
    const openEphemeralTabButton = document.getElementById('openEphemeralTab');
    const messageList = document.getElementById('messageList');
    const noMessagesText = document.getElementById('noMessages');

    // Load saved disposable email on startup
    browserAPI.storage.local.get(['disposableEmail'], function(result) {
        if (result.disposableEmail) {
            disposableEmailInput.value = result.disposableEmail;
        }
    });

    // --- Disposable Email Functionality ---

    generateEmailButton.addEventListener('click', async () => {
        // In a real application, you'd make an API call to your backend here
        // Example: const response = await fetch('YOUR_BACKEND_API/generate-email');
        // const data = await response.json();
        // const newEmail = data.email;

        // For this example, we'll generate a dummy email
        const newEmail = `burner-${Date.now()}@example.com`; // Dummy email

        disposableEmailInput.value = newEmail;
        browserAPI.storage.local.set({ disposableEmail: newEmail });

        // Simulate fetching messages (this would be an API call to your backend)
        noMessagesText.style.display = 'none';
        messageList.innerHTML = '<li>Simulating message fetch...</li>';
        setTimeout(() => {
            messageList.innerHTML = '<li>[10:00 AM] Subject: Welcome! - From: System</li>';
            messageList.innerHTML += '<li>[10:05 AM] Subject: Your service confirmation - From: NoReply@service.com</li>';
        }, 1500);
    });

    copyEmailButton.addEventListener('click', () => {
        disposableEmailInput.select();
        document.execCommand('copy');
        // Provide visual feedback
        const originalText = copyEmailButton.textContent;
        copyEmailButton.textContent = 'Copied!';
        setTimeout(() => {
            copyEmailButton.textContent = originalText;
        }, 1500);
    });

    // --- Ephemeral Tab Functionality ---

    openEphemeralTabButton.addEventListener('click', async () => {
        const newTab = await browserAPI.tabs.create({ url: 'about:blank', active: true });
        // Store the tab ID to monitor it
        // This is a simplified approach. In a robust system, you'd track origin too.
        browserAPI.storage.local.set({ ephemeralTabId: newTab.id });

        alert("New ephemeral tab opened. Its data will *attempt* to be cleared when closed. (Limited Privacy Feature)");
    });
});